from django.contrib import admin
from .models import Meal, Profile
# Register your models here.
admin.site.register(Meal)
admin.site.register(Profile)
